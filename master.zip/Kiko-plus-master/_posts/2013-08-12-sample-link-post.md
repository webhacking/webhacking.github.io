---
layout: post
title: Sample Link Post
description: "This theme supports link posts, made famous by John Gruber. To use, just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done."
tags:
  - sample post
  - link post
comments: true
link: 'http://aweekj.github.io/Kiko-plus'
---
